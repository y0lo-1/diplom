#!/usr/bin/env python3
"""
Быстрый запуск построения карты: Gazebo + SLAM + RViz.
Эквивалент: ros2 launch turtlebro_bringup bringup.launch.py mode:=slam
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    pkg_bringup = get_package_share_directory('turtlebro_bringup')

    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_bringup, 'launch', 'bringup.launch.py')),
            launch_arguments={'mode': 'slam', 'rviz': 'true'}.items()
        )
    ])