from setuptools import setup
import os
from glob import glob

package_name = 'turtlebro_control'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='diploma',
    maintainer_email='student@example.com',
    description='TurtleBro control nodes (teleop, avoidance, goal sender)',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'teleop_keyboard = turtlebro_control.teleop_keyboard:main',
            'obstacle_avoidance = turtlebro_control.obstacle_avoidance:main',
            'goal_sender = turtlebro_control.goal_sender:main',
        ],
    },
)