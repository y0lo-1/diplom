#!/usr/bin/env python3
"""
Полный эксперимент: запуск навигации + автоматическая запись данных.
Запускает напрямую: gazebo, navigation, rviz, recorder.

Параметры:
    experiment_name - название эксперимента
    duration        - длительность записи (сек)

Пример:
    ros2 launch turtlebro_experiments experiment_navigation.launch.py \\
        experiment_name:=test1 duration:=120
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            TimerAction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_description = get_package_share_directory('turtlebro_description')
    pkg_nav = get_package_share_directory('turtlebro_navigation')
    pkg_nav2_bringup = get_package_share_directory('nav2_bringup')

    map_yaml = os.path.join(pkg_nav, 'maps', 'my_map.yaml')
    nav_params = os.path.join(pkg_nav, 'config', 'nav2_params.yaml')
    rviz_config = os.path.join(pkg_nav, 'rviz', 'nav2.rviz')

    exp_name = LaunchConfiguration('experiment_name')
    duration = LaunchConfiguration('duration')

    # 1. Gazebo с роботом
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_description, 'launch', 'gazebo.launch.py'))
    )

    # 2. Nav2 — через 5 секунд после Gazebo
    nav = TimerAction(
        period=5.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_nav2_bringup, 'launch', 'bringup_launch.py')),
                launch_arguments={
                    'map': map_yaml,
                    'use_sim_time': 'true',
                    'params_file': nav_params,
                    'autostart': 'true',
                }.items()
            )
        ]
    )

    # 3. RViz — через 8 секунд
    rviz = TimerAction(
        period=8.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2',
                arguments=['-d', rviz_config],
                parameters=[{'use_sim_time': True}],
                output='screen'
            )
        ]
    )

    # 4. Recorder — через 12 секунд (даём Nav2 полностью стартовать)
    recorder = TimerAction(
        period=12.0,
        actions=[
            Node(
                package='turtlebro_experiments',
                executable='experiment_recorder',
                name='experiment_recorder',
                output='screen',
                parameters=[{
                    'experiment_name': exp_name,
                    'duration': duration,
                }]
            )
        ]
    )

    return LaunchDescription([
        DeclareLaunchArgument('experiment_name', default_value='experiment'),
        DeclareLaunchArgument('duration', default_value='120'),
        gazebo,
        nav,
        rviz,
        recorder,
    ])