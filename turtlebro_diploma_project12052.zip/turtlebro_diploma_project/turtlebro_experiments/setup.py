from setuptools import setup
import os
from glob import glob

package_name = 'turtlebro_experiments'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
        (os.path.join('share', package_name, 'scripts'),
            glob('scripts/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='diploma',
    maintainer_email='student@example.com',
    description='TurtleBro experiment recording and analysis',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'experiment_recorder = turtlebro_experiments.experiment_recorder:main',
            'auto_navigator = turtlebro_experiments.auto_navigator:main',
        ],
    },
)