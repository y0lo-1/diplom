#!/usr/bin/env python3
"""
Анализ rosbag, записанного experiment_recorder.
Извлекает траекторию, скорости, расстояние до препятствий, строит графики.

Использование:
    python3 analyze_experiment.py /путь/к/папке/эксперимента
"""
import os
import sys
import json
import sqlite3
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')  # без GUI - сохраняем в файл
import matplotlib.pyplot as plt

try:
    from rosbags.rosbag2 import Reader
    from rosbags.typesys import Stores, get_typestore
except ImportError:
    print("Нужно установить rosbags: pip install rosbags --break-system-packages")
    sys.exit(1)


def read_rosbag(bag_path):
    """Читает rosbag2 и возвращает словари с сообщениями по топикам."""
    data = {
        'odom': {'t': [], 'x': [], 'y': [], 'vx': [], 'wz': [], 'theta': []},
        'cmd_vel': {'t': [], 'vx': [], 'wz': []},
        'scan': {'t': [], 'min_range': [], 'mean_range': []},
        'plan': {'points': []},
        'goal_pose': {'t': [], 'x': [], 'y': []},
    }

    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with Reader(bag_path) as reader:
        connections = reader.connections
        topic_types = {c.topic: c.msgtype for c in connections}
        print(f'Топики в rosbag: {list(topic_types.keys())}')

        for connection, timestamp, rawdata in reader.messages():
            topic = connection.topic
            t_sec = timestamp * 1e-9
            msg = typestore.deserialize_cdr(rawdata, connection.msgtype)

            if topic == '/odom':
                px = msg.pose.pose.position.x
                py = msg.pose.pose.position.y
                qz = msg.pose.pose.orientation.z
                qw = msg.pose.pose.orientation.w
                theta = 2 * np.arctan2(qz, qw)
                data['odom']['t'].append(t_sec)
                data['odom']['x'].append(px)
                data['odom']['y'].append(py)
                data['odom']['vx'].append(msg.twist.twist.linear.x)
                data['odom']['wz'].append(msg.twist.twist.angular.z)
                data['odom']['theta'].append(theta)

            elif topic == '/cmd_vel':
                data['cmd_vel']['t'].append(t_sec)
                data['cmd_vel']['vx'].append(msg.linear.x)
                data['cmd_vel']['wz'].append(msg.angular.z)

            elif topic == '/scan':
                ranges = np.array(msg.ranges)
                ranges = ranges[np.isfinite(ranges)]
                if len(ranges) > 0:
                    data['scan']['t'].append(t_sec)
                    data['scan']['min_range'].append(float(np.min(ranges)))
                    data['scan']['mean_range'].append(float(np.mean(ranges)))

            elif topic == '/plan':
                pts = [(p.pose.position.x, p.pose.position.y)
                       for p in msg.poses]
                if pts:
                    data['plan']['points'].append(pts)

            elif topic == '/goal_pose':
                data['goal_pose']['t'].append(t_sec)
                data['goal_pose']['x'].append(msg.pose.position.x)
                data['goal_pose']['y'].append(msg.pose.position.y)

    return data


def normalize_time(times, t0):
    return [t - t0 for t in times]


def plot_trajectory(data, output_dir, exp_name):
    """График 1: Траектория робота в пространстве + планы Nav2 + цели."""
    fig, ax = plt.subplots(figsize=(10, 8))

    if data['odom']['x']:
        ax.plot(data['odom']['x'], data['odom']['y'],
                'b-', linewidth=2, label='Фактическая траектория (одометрия)')
        # старт и финиш
        ax.plot(data['odom']['x'][0], data['odom']['y'][0],
                'go', markersize=15, label='Старт', zorder=5)
        ax.plot(data['odom']['x'][-1], data['odom']['y'][-1],
                'rs', markersize=15, label='Финиш', zorder=5)

    # Глобальные планы (если есть)
    for i, pts in enumerate(data['plan']['points'][::20]):  # каждый 20-й план
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        ax.plot(xs, ys, 'g--', alpha=0.3, linewidth=1,
                label='Глобальный план Nav2' if i == 0 else None)

    # Цели
    if data['goal_pose']['x']:
        ax.scatter(data['goal_pose']['x'], data['goal_pose']['y'],
                   marker='*', s=200, c='red', edgecolors='black',
                   label='Целевые точки', zorder=4)

    ax.set_xlabel('X, м', fontsize=12)
    ax.set_ylabel('Y, м', fontsize=12)
    ax.set_title(f'Траектория робота — {exp_name}', fontsize=14)
    ax.grid(True, alpha=0.3)
    ax.legend(loc='best')
    ax.set_aspect('equal')

    out = os.path.join(output_dir, 'trajectory.png')
    plt.tight_layout()
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  ✅ {out}')


def plot_velocities(data, output_dir, exp_name):
    """График 2: Профиль скоростей во времени."""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), sharex=True)

    if data['odom']['t']:
        t0 = data['odom']['t'][0]

        # Фактические скорости (одометрия)
        t_odom = normalize_time(data['odom']['t'], t0)
        ax1.plot(t_odom, data['odom']['vx'],
                 'b-', linewidth=1.5, label='Фактическая v (одометрия)')
        ax2.plot(t_odom, data['odom']['wz'],
                 'b-', linewidth=1.5, label='Фактическая ω (одометрия)')

        # Команды (cmd_vel)
        if data['cmd_vel']['t']:
            t_cmd = normalize_time(data['cmd_vel']['t'], t0)
            ax1.plot(t_cmd, data['cmd_vel']['vx'],
                     'r--', linewidth=1, alpha=0.7, label='Команда v (cmd_vel)')
            ax2.plot(t_cmd, data['cmd_vel']['wz'],
                     'r--', linewidth=1, alpha=0.7, label='Команда ω (cmd_vel)')

    ax1.set_ylabel('Линейная скорость, м/с', fontsize=12)
    ax1.set_title(f'Профиль скоростей — {exp_name}', fontsize=14)
    ax1.grid(True, alpha=0.3)
    ax1.legend(loc='best')
    ax1.axhline(0, color='k', linewidth=0.5)

    ax2.set_ylabel('Угловая скорость, рад/с', fontsize=12)
    ax2.set_xlabel('Время, с', fontsize=12)
    ax2.grid(True, alpha=0.3)
    ax2.legend(loc='best')
    ax2.axhline(0, color='k', linewidth=0.5)

    out = os.path.join(output_dir, 'velocities.png')
    plt.tight_layout()
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  ✅ {out}')


def plot_lidar(data, output_dir, exp_name):
    """График 3: Минимальное расстояние до препятствия во времени."""
    if not data['scan']['t']:
        return

    fig, ax = plt.subplots(figsize=(12, 5))
    t0 = data['scan']['t'][0]
    t = normalize_time(data['scan']['t'], t0)

    ax.plot(t, data['scan']['min_range'], 'r-', linewidth=1, label='Min')
    ax.plot(t, data['scan']['mean_range'], 'b-', linewidth=1, alpha=0.6, label='Mean')
    ax.axhline(0.25, color='orange', linestyle='--', label='Порог безопасности (0.25 м)')

    ax.set_xlabel('Время, с', fontsize=12)
    ax.set_ylabel('Расстояние, м', fontsize=12)
    ax.set_title(f'Показания лидара — {exp_name}', fontsize=14)
    ax.grid(True, alpha=0.3)
    ax.legend(loc='best')

    out = os.path.join(output_dir, 'lidar.png')
    plt.tight_layout()
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  ✅ {out}')


def compute_metrics(data):
    """Расчёт численных метрик."""
    metrics = {}

    if data['odom']['x']:
        xs = np.array(data['odom']['x'])
        ys = np.array(data['odom']['y'])
        # длина траектории
        dx = np.diff(xs)
        dy = np.diff(ys)
        metrics['path_length_m'] = float(np.sum(np.sqrt(dx**2 + dy**2)))
        # длительность
        metrics['duration_sec'] = float(data['odom']['t'][-1] - data['odom']['t'][0])
        # скорости
        vx = np.array(data['odom']['vx'])
        metrics['max_linear_speed_mps'] = float(np.max(np.abs(vx)))
        metrics['mean_linear_speed_mps'] = float(np.mean(np.abs(vx)))
        # средняя путевая скорость
        if metrics['duration_sec'] > 0:
            metrics['avg_path_speed_mps'] = metrics['path_length_m'] / metrics['duration_sec']

    if data['scan']['min_range']:
        metrics['min_obstacle_distance_m'] = float(np.min(data['scan']['min_range']))
        metrics['mean_obstacle_distance_m'] = float(np.mean(data['scan']['min_range']))

    metrics['num_goals_sent'] = len(data['goal_pose']['x'])
    metrics['num_plans_received'] = len(data['plan']['points'])

    return metrics


def main():
    if len(sys.argv) < 2:
        print('Использование: python3 analyze_experiment.py <папка_эксперимента>')
        print('Пример: python3 analyze_experiment.py ~/turtlebro_ws/experiments/test1_20250101_120000')
        sys.exit(1)

    exp_dir = os.path.expanduser(sys.argv[1])
    if not os.path.isdir(exp_dir):
        print(f'Папка {exp_dir} не найдена')
        sys.exit(1)

    bag_dir = os.path.join(exp_dir, 'rosbag')
    if not os.path.isdir(bag_dir):
        print(f'Rosbag не найден в {bag_dir}')
        sys.exit(1)

    exp_name = Path(exp_dir).name
    print(f'\n=== Анализ эксперимента: {exp_name} ===')
    print('Чтение rosbag...')
    data = read_rosbag(bag_dir)

    print(f'  /odom:      {len(data["odom"]["t"])} сообщений')
    print(f'  /cmd_vel:   {len(data["cmd_vel"]["t"])} сообщений')
    print(f'  /scan:      {len(data["scan"]["t"])} сообщений')
    print(f'  /plan:      {len(data["plan"]["points"])} планов')
    print(f'  /goal_pose: {len(data["goal_pose"]["x"])} целей')

    print('\nПостроение графиков:')
    plots_dir = os.path.join(exp_dir, 'plots')
    os.makedirs(plots_dir, exist_ok=True)
    plot_trajectory(data, plots_dir, exp_name)
    plot_velocities(data, plots_dir, exp_name)
    plot_lidar(data, plots_dir, exp_name)

    print('\nРасчёт метрик:')
    metrics = compute_metrics(data)
    for k, v in metrics.items():
        print(f'  {k}: {v}')

    metrics_file = os.path.join(exp_dir, 'metrics.json')
    with open(metrics_file, 'w') as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)
    print(f'\n✅ Метрики сохранены: {metrics_file}')
    print(f'✅ Графики сохранены: {plots_dir}/')


if __name__ == '__main__':
    main()