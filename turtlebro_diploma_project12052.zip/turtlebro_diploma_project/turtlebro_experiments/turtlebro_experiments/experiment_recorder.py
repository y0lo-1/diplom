#!/usr/bin/env python3
"""
Узел для автоматической записи экспериментов TurtleBro.
Запускает запись rosbag нужных топиков, сохраняет метаданные.

Использование:
    ros2 run turtlebro_experiments experiment_recorder \\
        --ros-args -p experiment_name:=test1 -p duration:=120
"""
import os
import subprocess
import signal
import time
import json
from datetime import datetime

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry


class ExperimentRecorder(Node):
    def __init__(self):
        super().__init__('experiment_recorder')

        self.declare_parameter('experiment_name', 'experiment')
        self.declare_parameter('duration', 120)  # секунд
        self.declare_parameter('output_dir',
                               os.path.expanduser('~/turtlebro_ws/experiments'))

        self.exp_name = self.get_parameter('experiment_name').value
        self.duration = self.get_parameter('duration').value
        self.output_dir = self.get_parameter('output_dir').value

        # Создаём папку эксперимента
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.exp_dir = os.path.join(
            self.output_dir, f'{self.exp_name}_{timestamp}')
        os.makedirs(self.exp_dir, exist_ok=True)

        self.get_logger().info(f'=== Эксперимент: {self.exp_name} ===')
        self.get_logger().info(f'Папка: {self.exp_dir}')
        self.get_logger().info(f'Длительность: {self.duration} сек')

        # Топики для записи
        self.topics = [
            '/odom',
            '/scan',
            '/cmd_vel',
            '/tf',
            '/tf_static',
            '/map',
            '/plan',           # глобальный план Nav2
            '/local_plan',     # локальный план DWB
            '/amcl_pose',      # поза AMCL
            '/goal_pose',      # отправленные цели
        ]

        # Запускаем rosbag через subprocess
        bag_path = os.path.join(self.exp_dir, 'rosbag')
        cmd = ['ros2', 'bag', 'record', '-o', bag_path] + self.topics
        self.get_logger().info(f'Команда: {" ".join(cmd)}')

        self.bag_process = subprocess.Popen(
            cmd, preexec_fn=os.setsid)

        self.start_time = time.time()

        # Подписываемся на одометрию для подсчёта статистики
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_cb, 10)

        self.last_x = None
        self.last_y = None
        self.total_distance = 0.0
        self.max_speed = 0.0
        self.odom_count = 0

        # Таймер автоматической остановки
        self.timer = self.create_timer(1.0, self.check_timeout)

    def odom_cb(self, msg: Odometry):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        v = msg.twist.twist.linear.x

        if self.last_x is not None:
            dx = x - self.last_x
            dy = y - self.last_y
            self.total_distance += (dx * dx + dy * dy) ** 0.5

        self.last_x = x
        self.last_y = y
        self.max_speed = max(self.max_speed, abs(v))
        self.odom_count += 1

    def check_timeout(self):
        elapsed = time.time() - self.start_time
        remaining = self.duration - elapsed

        if remaining > 0:
            self.get_logger().info(
                f'Осталось {remaining:.0f} сек | '
                f'путь: {self.total_distance:.2f} м | '
                f'v_max: {self.max_speed:.2f} м/с',
                throttle_duration_sec=5.0)
        else:
            self.get_logger().info('Время вышло — останавливаем запись.')
            self.stop_recording()
            rclpy.shutdown()

    def stop_recording(self):
        # Останавливаем rosbag
        if self.bag_process and self.bag_process.poll() is None:
            os.killpg(os.getpgid(self.bag_process.pid), signal.SIGINT)
            self.bag_process.wait(timeout=10)

        # Сохраняем метаданные
        elapsed = time.time() - self.start_time
        metadata = {
            'experiment_name': self.exp_name,
            'start_time': datetime.fromtimestamp(self.start_time).isoformat(),
            'duration_sec': elapsed,
            'total_distance_m': round(self.total_distance, 3),
            'max_speed_mps': round(self.max_speed, 3),
            'average_speed_mps': round(self.total_distance / max(elapsed, 0.1), 3),
            'odom_samples': self.odom_count,
            'topics_recorded': self.topics,
        }

        meta_file = os.path.join(self.exp_dir, 'metadata.json')
        with open(meta_file, 'w') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)

        self.get_logger().info(f'Метаданные сохранены: {meta_file}')
        self.get_logger().info(f'=== РЕЗУЛЬТАТЫ ===')
        self.get_logger().info(f'Длительность:   {elapsed:.1f} сек')
        self.get_logger().info(f'Пройдено:       {self.total_distance:.2f} м')
        self.get_logger().info(f'Макс. скорость: {self.max_speed:.2f} м/с')
        self.get_logger().info(f'Средняя скор.:  {metadata["average_speed_mps"]} м/с')


def main():
    rclpy.init()
    node = ExperimentRecorder()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Прервано пользователем.')
        node.stop_recording()
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()


if __name__ == '__main__':
    main()