#!/usr/bin/env python3
"""
Автоматический навигатор по заданному маршруту.
Читает список целей из YAML, отправляет их через Nav2 navigate_to_pose,
замеряет метрики каждой цели и сводный результат.

Использование:
    ros2 run turtlebro_experiments auto_navigator \\
        --ros-args -p route:=square -p timeout:=60.0
"""
import os
import time
import math
import json
import yaml
from datetime import datetime
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry


# ANSI-цвета для красивого вывода
class C:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    END = '\033[0m'


class AutoNavigator(Node):
    def __init__(self):
        super().__init__('auto_navigator')

        # Параметры
        self.declare_parameter('route', 'simple')
        self.declare_parameter('timeout', 60.0)  # на одну цель
        self.declare_parameter('routes_file', '')
        self.declare_parameter('output_dir',
                               os.path.expanduser('~/turtlebro_ws/experiments'))

        self.route_name = self.get_parameter('route').value
        self.goal_timeout = self.get_parameter('timeout').value
        self.output_dir = self.get_parameter('output_dir').value

        routes_file = self.get_parameter('routes_file').value
        if not routes_file:
            # путь по умолчанию
            from ament_index_python.packages import get_package_share_directory
            pkg = get_package_share_directory('turtlebro_experiments')
            routes_file = os.path.join(pkg, 'config', 'routes.yaml')

        # Загружаем маршрут
        with open(routes_file, 'r') as f:
            routes = yaml.safe_load(f)['routes']

        if self.route_name not in routes:
            self.get_logger().error(
                f'Маршрут "{self.route_name}" не найден. '
                f'Доступные: {list(routes.keys())}')
            rclpy.shutdown()
            return

        self.route_data = routes[self.route_name]
        self.goals = self.route_data['goals']

        # Action client для Nav2
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # Подписка на одометрию для замера пути
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_cb, 10)
        self.last_x = None
        self.last_y = None
        self.current_path_length = 0.0

        # Накопители результатов
        self.results = []
        self.current_goal_idx = 0
        self.current_goal_start_time = 0.0
        self.current_goal_start_pos = (0.0, 0.0)

        # Запуск
        self.print_header()
        self.timer = self.create_timer(1.0, self.start_navigation)
        self.started = False

    def print_header(self):
        n = len(self.goals)
        print(f'\n{C.BOLD}{C.CYAN}{"=" * 60}{C.END}')
        print(f'{C.BOLD}  АВТОМАТИЧЕСКИЙ ТЕСТ НАВИГАЦИИ{C.END}')
        print(f'{C.BOLD}{C.CYAN}{"=" * 60}{C.END}')
        print(f'  Маршрут:     {C.YELLOW}{self.route_name}{C.END}')
        print(f'  Описание:    {self.route_data.get("description", "")}')
        print(f'  Точек:       {n}')
        print(f'  Таймаут:     {self.goal_timeout} сек/цель')
        print(f'{C.BOLD}{C.CYAN}{"=" * 60}{C.END}\n')

    def odom_cb(self, msg: Odometry):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        if self.last_x is not None:
            dx = x - self.last_x
            dy = y - self.last_y
            self.current_path_length += math.sqrt(dx * dx + dy * dy)
        self.last_x = x
        self.last_y = y

    def start_navigation(self):
        if self.started:
            return
        self.started = True
        self.timer.cancel()

        self.get_logger().info('Ожидание сервера навигации...')
        if not self._action_client.wait_for_server(timeout_sec=15.0):
            self.get_logger().error('Nav2 не готов. Убедитесь, что Initial Pose установлен.')
            rclpy.shutdown()
            return

        self.send_next_goal()

    def send_next_goal(self):
        if self.current_goal_idx >= len(self.goals):
            self.print_summary()
            rclpy.shutdown()
            return

        goal_dict = self.goals[self.current_goal_idx]
        x, y, yaw = goal_dict['x'], goal_dict['y'], goal_dict['yaw']

        goal = NavigateToPose.Goal()
        goal.pose = PoseStamped()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = float(x)
        goal.pose.pose.position.y = float(y)
        goal.pose.pose.orientation.z = math.sin(yaw / 2.0)
        goal.pose.pose.orientation.w = math.cos(yaw / 2.0)

        n = len(self.goals)
        print(f'\n{C.BOLD}{C.BLUE}[Цель {self.current_goal_idx + 1}/{n}]{C.END} '
              f'→ ({x:+.2f}, {y:+.2f}, yaw={yaw:+.2f})')

        self.current_goal_start_time = time.time()
        self.current_goal_start_pos = (self.last_x or 0.0, self.last_y or 0.0)
        self.current_path_length = 0.0

        # таймаут на цель
        self._timeout_timer = self.create_timer(
            self.goal_timeout, self._on_timeout)

        future = self._action_client.send_goal_async(
            goal, feedback_callback=self._fb_cb)
        future.add_done_callback(self._goal_response_cb)

    def _fb_cb(self, feedback_msg):
        fb = feedback_msg.feedback
        # выводим прогресс не чаще раза в 3 секунды
        if not hasattr(self, '_last_fb_time') or \
                time.time() - self._last_fb_time > 3.0:
            print(f'    ... осталось {fb.distance_remaining:.2f} м')
            self._last_fb_time = time.time()

    def _goal_response_cb(self, future):
        handle = future.result()
        if not handle.accepted:
            self._finish_goal(success=False, status='REJECTED')
            return
        result_future = handle.get_result_async()
        result_future.add_done_callback(self._result_cb)
        self._current_handle = handle

    def _result_cb(self, future):
        status = future.result().status
        # 4 = SUCCEEDED
        success = (status == 4)
        status_name = {1: 'CANCELED', 2: 'EXECUTING', 4: 'SUCCEEDED',
                       5: 'CANCELED', 6: 'ABORTED'}.get(status, f'UNKNOWN({status})')
        self._finish_goal(success=success, status=status_name)

    def _on_timeout(self):
        self._timeout_timer.cancel()
        print(f'    {C.RED}⏰ Таймаут — отменяем цель{C.END}')
        if hasattr(self, '_current_handle'):
            self._current_handle.cancel_goal_async()
        self._finish_goal(success=False, status='TIMEOUT')

    def _finish_goal(self, success, status):
        try:
            self._timeout_timer.cancel()
        except Exception:
            pass

        elapsed = time.time() - self.current_goal_start_time
        path = self.current_path_length
        target = self.goals[self.current_goal_idx]
        final_pos = (self.last_x or 0.0, self.last_y or 0.0)

        # Евклидово отклонение от цели
        dx = final_pos[0] - target['x']
        dy = final_pos[1] - target['y']
        deviation = math.sqrt(dx * dx + dy * dy)

        # Прямая дистанция от старта до цели
        sx, sy = self.current_goal_start_pos
        straight_dist = math.sqrt(
            (target['x'] - sx) ** 2 + (target['y'] - sy) ** 2)

        result = {
            'goal_index': self.current_goal_idx + 1,
            'target_x': target['x'],
            'target_y': target['y'],
            'target_yaw': target['yaw'],
            'final_x': round(final_pos[0], 3),
            'final_y': round(final_pos[1], 3),
            'time_sec': round(elapsed, 2),
            'path_length_m': round(path, 3),
            'straight_distance_m': round(straight_dist, 3),
            'deviation_m': round(deviation, 3),
            'efficiency': round(straight_dist / path, 3) if path > 0 else 0,
            'status': status,
            'success': success,
        }
        self.results.append(result)

        # Печать
        color = C.GREEN if success else C.RED
        icon = '✅' if success else '❌'
        print(f'    {color}{icon} {status}{C.END} | '
              f't={elapsed:.1f}с | путь={path:.2f}м | '
              f'отклонение={deviation:.2f}м')

        self.current_goal_idx += 1

        # Маленькая пауза перед следующей целью
        self.create_timer(2.0, self._next_after_delay)

    def _next_after_delay(self):
        # одноразовый таймер
        if not hasattr(self, '_delay_used'):
            self._delay_used = set()
        # Каждый вызов делаем уникальную задержку через id таймера
        self.send_next_goal()
        # отменяем все таймеры >2 секунд после старта
        for t in list(self._timers if hasattr(self, '_timers') else []):
            try:
                t.cancel()
            except Exception:
                pass

    def print_summary(self):
        n_total = len(self.results)
        n_success = sum(1 for r in self.results if r['success'])
        total_time = sum(r['time_sec'] for r in self.results)
        total_path = sum(r['path_length_m'] for r in self.results)
        total_straight = sum(r['straight_distance_m'] for r in self.results)
        avg_deviation = (sum(r['deviation_m'] for r in self.results) /
                         n_total if n_total > 0 else 0)
        avg_efficiency = (sum(r['efficiency'] for r in self.results) /
                          n_total if n_total > 0 else 0)

        print(f'\n{C.BOLD}{C.CYAN}{"=" * 70}{C.END}')
        print(f'{C.BOLD}  СВОДНАЯ ТАБЛИЦА — {self.route_name}{C.END}')
        print(f'{C.BOLD}{C.CYAN}{"=" * 70}{C.END}')
        print(f'{"#":<3}{"Цель (x, y)":<18}{"Время, с":<10}'
              f'{"Путь, м":<10}{"Откл., м":<10}{"Статус":<12}')
        print('-' * 70)
        for r in self.results:
            color = C.GREEN if r['success'] else C.RED
            print(f'{r["goal_index"]:<3}'
                  f'({r["target_x"]:+.1f}, {r["target_y"]:+.1f})    '
                  f'{r["time_sec"]:<10.2f}'
                  f'{r["path_length_m"]:<10.2f}'
                  f'{r["deviation_m"]:<10.3f}'
                  f'{color}{r["status"]:<12}{C.END}')
        print('-' * 70)
        print(f'  Успешно:           {C.GREEN}{n_success}/{n_total}{C.END}')
        print(f'  Общее время:       {total_time:.1f} сек')
        print(f'  Общий путь:        {total_path:.2f} м')
        print(f'  Прямой путь:       {total_straight:.2f} м')
        print(f'  Эффективность:     {avg_efficiency:.1%} (1.0 = идеально прямо)')
        print(f'  Среднее отклон.:   {avg_deviation:.3f} м')
        print(f'{C.BOLD}{C.CYAN}{"=" * 70}{C.END}\n')

        # Сохраняем JSON
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        out_dir = os.path.join(self.output_dir,
                               f'autonav_{self.route_name}_{timestamp}')
        os.makedirs(out_dir, exist_ok=True)

        report = {
            'route_name': self.route_name,
            'description': self.route_data.get('description', ''),
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'goals_total': n_total,
                'goals_success': n_success,
                'total_time_sec': round(total_time, 2),
                'total_path_m': round(total_path, 2),
                'total_straight_m': round(total_straight, 2),
                'avg_efficiency': round(avg_efficiency, 3),
                'avg_deviation_m': round(avg_deviation, 3),
            },
            'goals': self.results,
        }

        report_file = os.path.join(out_dir, 'report.json')
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        # Markdown-таблица для диплома
        md_file = os.path.join(out_dir, 'report.md')
        with open(md_file, 'w') as f:
            f.write(f'# Отчёт автотеста: {self.route_name}\n\n')
            f.write(f'**Описание**: {self.route_data.get("description", "")}\n\n')
            f.write(f'**Дата**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n\n')
            f.write('## Результаты по точкам\n\n')
            f.write('| # | Цель (x, y) | Время, с | Путь, м | Прямой, м | Отклонение, м | Статус |\n')
            f.write('|---|-------------|----------|---------|-----------|---------------|--------|\n')
            for r in self.results:
                f.write(f'| {r["goal_index"]} | '
                        f'({r["target_x"]:+.2f}, {r["target_y"]:+.2f}) | '
                        f'{r["time_sec"]:.2f} | '
                        f'{r["path_length_m"]:.2f} | '
                        f'{r["straight_distance_m"]:.2f} | '
                        f'{r["deviation_m"]:.3f} | '
                        f'{r["status"]} |\n')
            f.write(f'\n## Сводные метрики\n\n')
            f.write(f'- **Успешно**: {n_success}/{n_total}\n')
            f.write(f'- **Общее время**: {total_time:.1f} сек\n')
            f.write(f'- **Общий путь**: {total_path:.2f} м\n')
            f.write(f'- **Прямой путь**: {total_straight:.2f} м\n')
            f.write(f'- **Эффективность**: {avg_efficiency:.1%}\n')
            f.write(f'- **Среднее отклонение**: {avg_deviation:.3f} м\n')

        print(f'  📄 Отчёт JSON:     {report_file}')
        print(f'  📄 Отчёт Markdown: {md_file}\n')


def main():
    rclpy.init()
    node = AutoNavigator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Прервано пользователем.')
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()


if __name__ == '__main__':
    main()