#!/usr/bin/env python3
"""
Запуск полной системы SLAM: Gazebo + slam_toolbox + RViz.
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            TimerAction, LogInfo)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_description = get_package_share_directory('turtlebro_description')
    pkg_slam = get_package_share_directory('turtlebro_slam')

    rviz_config = os.path.join(pkg_slam, 'rviz', 'slam.rviz')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    # 1. Gazebo + робот
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_description, 'launch', 'gazebo.launch.py'))
    )

    # 2. SLAM через 5 секунд
    slam = TimerAction(
        period=5.0,
        actions=[
            LogInfo(msg='[full_slam] Запускается SLAM toolbox...'),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_slam, 'launch', 'online_async.launch.py')))
        ]
    )

    # 3. RViz через 6 секунд
    rviz = TimerAction(
        period=6.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2',
                arguments=['-d', rviz_config],
                parameters=[{'use_sim_time': True}],
                output='screen'
            )
        ]
    )

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),
        gazebo,
        slam,
        rviz,
    ])