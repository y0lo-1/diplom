#!/usr/bin/env python3
"""
Главный launch-файл TurtleBro - запускает всю систему одной командой.

Режимы работы (выбираются аргументами):
    mode:=simulation   - только Gazebo + робот (по умолчанию)
    mode:=slam         - Gazebo + SLAM + RViz (для построения карты)
    mode:=navigation   - Gazebo + Nav2 + RViz (автономная навигация)

Дополнительные аргументы:
    headless:=true     - запуск Gazebo без GUI (для виртуальных машин)
    rviz:=false        - не запускать RViz
    teleop:=true       - запустить teleop_keyboard в новом терминале

Примеры:
    ros2 launch turtlebro_bringup bringup.launch.py mode:=slam
    ros2 launch turtlebro_bringup bringup.launch.py mode:=navigation
    ros2 launch turtlebro_bringup bringup.launch.py mode:=simulation headless:=true
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            TimerAction, GroupAction, LogInfo)
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node


def generate_launch_description():
    # ============== ПУТИ К ПАКЕТАМ ==============
    pkg_description = get_package_share_directory('turtlebro_description')
    pkg_slam = get_package_share_directory('turtlebro_slam')
    pkg_nav = get_package_share_directory('turtlebro_navigation')

    # ============== АРГУМЕНТЫ ==============
    mode = LaunchConfiguration('mode')
    headless = LaunchConfiguration('headless')
    use_rviz = LaunchConfiguration('rviz')
    use_sim_time = LaunchConfiguration('use_sim_time')

    # ============== ВЫБОР GAZEBO ЛАУНЧА ==============
    gazebo_normal = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_description, 'launch', 'gazebo.launch.py')),
        condition=UnlessCondition(headless),
    )

    gazebo_headless = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_description, 'launch', 'gazebo_headless.launch.py')),
        condition=IfCondition(headless),
    )

    # ============== SLAM (mode = slam) ==============
    slam = TimerAction(
        period=5.0,
        actions=[
            LogInfo(msg='[bringup] Запускается SLAM toolbox...'),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_slam, 'launch', 'online_async.launch.py')),
            )
        ],
        condition=IfCondition(PythonExpression(["'", mode, "' == 'slam'"]))
    )

    rviz_slam = TimerAction(
        period=6.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2_slam',
                arguments=['-d', os.path.join(pkg_slam, 'rviz', 'slam.rviz')],
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            )
        ],
        condition=IfCondition(PythonExpression([
            "'", mode, "' == 'slam' and '", use_rviz, "' == 'true'"]))
    )

    # ============== NAVIGATION (mode = navigation) ==============
    nav = TimerAction(
        period=5.0,
        actions=[
            LogInfo(msg='[bringup] Запускается Nav2 stack...'),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_nav, 'launch', 'navigation.launch.py')),
            )
        ],
        condition=IfCondition(PythonExpression(["'", mode, "' == 'navigation'"]))
    )

    rviz_nav = TimerAction(
        period=8.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2_nav',
                arguments=['-d', os.path.join(pkg_nav, 'rviz', 'nav2.rviz')],
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            )
        ],
        condition=IfCondition(PythonExpression([
            "'", mode, "' == 'navigation' and '", use_rviz, "' == 'true'"]))
    )

    # ============== SIMULATION (mode = simulation) - только RViz по запросу ==============
    rviz_sim = TimerAction(
        period=5.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2_sim',
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            )
        ],
        condition=IfCondition(PythonExpression([
            "'", mode, "' == 'simulation' and '", use_rviz, "' == 'true'"]))
    )

    return LaunchDescription([
        # ============== ДЕКЛАРАЦИИ АРГУМЕНТОВ ==============
        DeclareLaunchArgument(
            'mode',
            default_value='simulation',
            description='Режим работы: simulation | slam | navigation'),

        DeclareLaunchArgument(
            'headless',
            default_value='false',
            description='Запускать Gazebo без GUI (true/false)'),

        DeclareLaunchArgument(
            'rviz',
            default_value='true',
            description='Запускать RViz (true/false)'),

        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Использовать симуляционное время'),

        LogInfo(msg=['[bringup] Запуск в режиме: ', mode]),

        # ============== ДЕЙСТВИЯ ==============
        gazebo_normal,
        gazebo_headless,
        slam,
        rviz_slam,
        nav,
        rviz_nav,
        rviz_sim,
    ])