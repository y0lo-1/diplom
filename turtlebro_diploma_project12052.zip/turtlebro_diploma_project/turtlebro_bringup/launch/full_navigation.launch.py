#!/usr/bin/env python3
"""
Запуск полной системы навигации: Gazebo + Nav2 + RViz.
Прямой launch без вложенных обёрток - надёжнее в Humble.
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            TimerAction, LogInfo)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_description = get_package_share_directory('turtlebro_description')
    pkg_nav = get_package_share_directory('turtlebro_navigation')
    pkg_nav2_bringup = get_package_share_directory('nav2_bringup')

    map_yaml = os.path.join(pkg_nav, 'maps', 'my_map.yaml')
    nav_params = os.path.join(pkg_nav, 'config', 'nav2_params.yaml')
    rviz_config = os.path.join(pkg_nav, 'rviz', 'nav2.rviz')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    # 1. Gazebo + робот
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_description, 'launch', 'gazebo.launch.py'))
    )

    # 2. Nav2 через 5 секунд
    nav = TimerAction(
        period=5.0,
        actions=[
            LogInfo(msg='[full_navigation] Запускается Nav2 stack...'),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_nav2_bringup, 'launch', 'bringup_launch.py')),
                launch_arguments={
                    'map': map_yaml,
                    'use_sim_time': 'true',
                    'params_file': nav_params,
                    'autostart': 'true',
                }.items()
            )
        ]
    )

    # 3. RViz через 8 секунд
    rviz = TimerAction(
        period=8.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2',
                arguments=['-d', rviz_config],
                parameters=[{'use_sim_time': True}],
                output='screen'
            )
        ]
    )

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),
        gazebo,
        nav,
        rviz,
    ])